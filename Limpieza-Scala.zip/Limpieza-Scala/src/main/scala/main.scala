@main
def main(): Unit = {
  println("Hello world!")
}